<?php
/*
*  Payment Modules
*
* @copyright  Copyright 2016 by Easebuzz
* @license    http://opensource.org/licenses/GPL-3.0  Open Software License (GPL 3.0)
*/

// Heading
$_['heading_title'] = 'Easebuzz';

// Text
$_['text_title'] = 'Pay Online (Upto 50% returns)';
$_['text_easebuzz_order'] = 'Order';
$_['text_easebuzz_discount'] = 'Discount';
$_['text_error_message'] = 'Something went wrong. You can not order by Easebuzz.';
